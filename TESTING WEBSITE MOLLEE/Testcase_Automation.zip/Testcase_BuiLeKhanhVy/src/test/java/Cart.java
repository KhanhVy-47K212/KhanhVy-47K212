import WebDriverWaitCustom.WebDriverWaitCustom;
import io.github.bonigarcia.wdm.WebDriverManager;
import org.openqa.selenium.*;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import java.time.Duration;


public class Cart {
    WebDriver test;
    WebDriverWaitCustom waitCustom;
    private WebDriverWaitCustom wait;

    @BeforeMethod
    public void setup() throws InterruptedException {
        WebDriverManager.chromedriver().setup();
        ChromeOptions options = new ChromeOptions();
        options.addArguments("--start-maximized");
        test = new ChromeDriver(options);
        test.get("http://localhost:8080/login?lang=en");
        WebElement user = test.findElement(By.xpath("//input[@name='username']"));
        user.sendKeys("vyahin6");
        WebElement pass = test.findElement(By.xpath("//input[@name='password']"));
        pass.sendKeys("qMe6Uq");
        WebElement button = test.findElement(By.xpath("//span[@class='button__text']"));
        button.click();
        Thread.sleep(4000);

        waitCustom = new WebDriverWaitCustom(test, Duration.ofSeconds(10));
    }

    @Test
// Kiểm tra người dùng có thể click vào xem sản phẩm
    public void runTestcase1() {
        try {
            // Tìm phần tử sản phẩm và chờ cho đến khi có thể click
            WebElement SP = waitCustom.findElementToBeClickableByXPath("//*[@id=\"products-1\"]/div/div/article[6]/div/h4/a");
            // Cuộn trang để phần tử sản phẩm có thể nhìn thấy
            ((JavascriptExecutor) test).executeScript("arguments[0].scrollIntoView(true);", SP);
            sleep(5000);
            // Click vào phần tử sản phẩm
            ((JavascriptExecutor) test).executeScript("arguments[0].click();", SP);
            sleep(5000);
            // Cuộn trang để nhìn chi tiết sản phẩm
            WebElement XemSP = waitCustom.findElementToBeClickableByXPath("/html/body/div[2]/main/div[1]/div/div/div[1]/div/ul/li[2]");
            ((JavascriptExecutor) test).executeScript("arguments[0].scrollIntoView(true);", XemSP);
            sleep(5000);
            // Kiểm tra nút "Add to cart" có xuất hiện sau khi click vào sản phẩm
            String buttonText = waitCustom.findElementToBeClickableByXPath("/html/body/div[2]/main/section/div/div[2]/div[2]/div/a/span").getText();
            Assert.assertEquals(buttonText, "Add to cart");

            System.out.println("Testcase pass");
        } catch (Exception e) {
            System.out.println("Testcase fail: " + e.getMessage());
            e.printStackTrace();
            Assert.assertEquals(true, false);
        }
    }

    @Test()
// Click vào sản phẩm và thêm sản phẩm vào giỏ hàng
    public void runTestcase2() {
        try {
            // Tìm phần tử sản phẩm và chờ cho đến khi có thể click
            WebElement SP = waitCustom.findElementToBeClickableByXPath("//*[@id=\"products-1\"]/div/div/article[6]/div/h4/a");
            // Cuộn trang để phần tử sản phẩm có thể nhìn thấy
            ((JavascriptExecutor) test).executeScript("arguments[0].scrollIntoView(true);", SP);
            sleep(5000);
            // Click vào phần tử sản phẩm
            ((JavascriptExecutor) test).executeScript("arguments[0].click();", SP);
            sleep(5000);
            // Kiểm tra nút "Add to cart" có xuất hiện sau khi click vào sản phẩm
            String Test = waitCustom.findElementToBeClickableByXPath("/html/body/div[2]/main/section/div/div[2]/div[2]/div/a/span").getText();
            Assert.assertEquals(Test, "Add to cart");
            // Tìm phần tử kích thước và cuộn trang để phần tử này có thể nhìn thấy
            WebElement Size = waitCustom.findElementToBeClickableByXPath("/html/body/div[2]/main/section/div/div[2]/div[2]/div/a/span");
            ((JavascriptExecutor) test).executeScript("arguments[0].scrollIntoView(true);", Size);
            sleep(5000);
            // Click vào phần tử kích thước
            ((JavascriptExecutor) test).executeScript("arguments[0].click();", Size);
            // Cuộn trang để nhìn chi tiết giỏ hàng
            WebElement XemSP = waitCustom.findElementToBeClickableByXPath("/html/body/div[2]/main/div[1]/div/div/div[1]/div/ul/li[2]");
            ((JavascriptExecutor) test).executeScript("arguments[0].scrollIntoView(true);", XemSP);
            sleep(5000);
            // Kiểm tra nút "Checkout" có xuất hiện sau khi thêm sản phẩm vào giỏ hàng
            String Test1 = waitCustom.findElementToBeClickableByXPath("/html/body/div[2]/main/div[2]/div[1]/aside/section/a/span").getText();
            Assert.assertEquals(Test1, "Checkout");

            System.out.println("Testcase pass");
        } catch (Exception e) {
            System.out.println("Testcase fail: " + e.getMessage());
            e.printStackTrace();
            Assert.assertEquals(true, false);
        }
    }

    public void addProductToCart() throws InterruptedException {
        WebElement SP = waitCustom.findElementToBeClickableByXPath("//*[@id=\"products-1\"]/div/div/article[6]/div/h4/a");
        ((JavascriptExecutor) test).executeScript("arguments[0].scrollIntoView(true);", SP);
        ((JavascriptExecutor) test).executeScript("arguments[0].click();", SP);
        WebElement addToCartButton = waitCustom.findElementToBeClickableByXPath("/html/body/div[2]/main/section/div/div[2]/div[2]/div/a/span");
        ((JavascriptExecutor) test).executeScript("arguments[0].scrollIntoView(true);", addToCartButton);
        ((JavascriptExecutor) test).executeScript("arguments[0].click();", addToCartButton);
    }

    @Test
    // CLick button [+] và kiểm tra cập nhật cột Total
    public void runTestcase3() {
        try {
            addProductToCart();

            // Bấm vào nút dấu cộng để tăng số lượng sản phẩm
            WebElement plusButton = waitCustom.findElementToBeClickableByXPath(
                    "/html/body/div[2]/main/div[2]/div[1]/div/div[1]/form/article/div/div[2]/div[2]/div[2]/div/button[2]");
            plusButton.click();
            sleep(3000);
            String oldTotalValue = "73.32 $";
            WebDriverWait wait = new WebDriverWait(test, Duration.ofSeconds(10));
            wait.until(ExpectedConditions.not(ExpectedConditions.textToBePresentInElementLocated(By.xpath(
                        "/html/body/div[2]/main/div[2]/div[1]/aside/section/div/div[2]/span"), oldTotalValue)
            ));
            String expectedNewTotalValue = "146.64 $";

            // Kiểm tra giá trị mới của cột Total
            WebElement totalElement = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("/html/body/div[2]/main/div[2]/div[1]/aside/section/div/div[2]/span")));
            String totalValue = totalElement.getText();
            Assert.assertEquals(totalValue, expectedNewTotalValue);

            System.out.println("Testcase pass");
        } catch (Exception e) {
            System.out.println("Testcase fail: " + e.getMessage());
            e.printStackTrace();
            Assert.assertEquals(true, false);
        }
    }

    @Test
    // Kiểm tra xác minh rằng nút giảm không hoạt động khi số lượng sản phẩm bằng 1
    public void runTestcase4() {
        try {
            addProductToCart();
            // Kiểm tra giá trị hiện tại của ô nhập số lượng
            WebElement quantityInput = waitCustom.findElementToBeClickableByXPath("//input[@value='1']");
            String quantityBeforeClick = quantityInput.getAttribute("value");
            Assert.assertEquals(quantityBeforeClick, "1");

            // Bấm vào nút giảm
            WebElement minusButton = waitCustom.findElementToBeClickableByXPath("/html/body/div[2]/main/div[2]/div[1]/div/div[1]/form/article/div/div[2]/div[2]/div[2]/div/button[1]");
            minusButton.click();
            Thread.sleep(5000);

            // Kiểm tra lại giá trị của ô nhập số lượng
            String quantityAfterClick = quantityInput.getAttribute("value");
            Assert.assertEquals(quantityAfterClick, "1");

            System.out.println("Testcase pass");
        } catch (Exception e) {
            System.out.println("Testcase fail: " + e.getMessage());
            e.printStackTrace();
            Assert.assertEquals(true, false);
        }
    }

    @Test
    // Kiểm tra người dùng không thể nhập ký tự khác số
    public void runTestcase5() {
        try {
            addProductToCart();

            // Thử nhập số <1
            appendToProductQuantity("abc");
            WebElement quantityInput = waitCustom.findElementToBeClickableByXPath("//input[@value='1']");
            String quantity = quantityInput.getAttribute("value");
            Assert.assertEquals(quantity, "1");

            appendToProductQuantity("-");
            quantity = quantityInput.getAttribute("value");
            Assert.assertEquals(quantity, "1");

            System.out.println("Testcase pass");
        } catch (Exception e) {
            System.out.println("Testcase fail: " + e.getMessage());
            e.printStackTrace();
            Assert.assertEquals(true, false);
        }
    }

    @Test
// Xóa số lượng hiện tại và điền số lượng mới
    public void runTestcase6() {
        try {
            addProductToCart();
            updateProductQuantity("5");
            String oldTotalValue = "73.32 $";
            WebDriverWait wait = new WebDriverWait(test, Duration.ofSeconds(5));
            wait.until(ExpectedConditions.not(
                    ExpectedConditions.textToBePresentInElementLocated(By.xpath("/html/body/div[2]/main/div[2]/div[1]/aside/section/div/div[2]/span"), oldTotalValue)
            ));
            String expectedNewTotalValue = "366.6 $";
            // Kiểm tra giá trị mới của cột Total
            WebElement totalElement = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("/html/body/div[2]/main/div[2]/div[1]/aside/section/div/div[2]/span")));
            String totalValue = totalElement.getText();
            Assert.assertEquals(totalValue, expectedNewTotalValue);

            System.out.println("Testcase pass");
        } catch (Exception e) {
            System.out.println("Testcase fail: " + e.getMessage());
            e.printStackTrace();
            Assert.assertEquals(true, false);
        }
    }


    @Test
    // CLick button [-] và kiểm tra cập nhật cột Total
    public void runTestcase7() {
        try {
            addProductToCart();
            updateProductQuantity("5");
            // Bấm vào nút dấu cộng để tăng số lượng sản phẩm
            WebElement giam = waitCustom.findElementToBeClickableByXPath("/html/body/div[2]/main/div[2]/div[1]/div/div[1]/form/article/div/div[2]/div[2]/div[2]/div/button[1]");
            giam.click();
            sleep(5000);
            String oldTotalValue = "73.32 $";
            WebDriverWait wait = new WebDriverWait(test, Duration.ofSeconds(15));
            wait.until(ExpectedConditions.not(ExpectedConditions.textToBePresentInElementLocated(By.xpath(
                    "/html/body/div[2]/main/div[2]/div[1]/aside/section/div/div[2]/span"), oldTotalValue)
            ));
            String expectedNewTotalValue = "293.28 $";

            // Kiểm tra giá trị mới của cột Total
            WebElement totalElement = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("/html/body/div[2]/main/div[2]/div[1]/aside/section/div/div[2]/span")));
            String totalValue = totalElement.getText();
            Assert.assertEquals(totalValue, expectedNewTotalValue);

            System.out.println("Testcase pass");
        } catch (Exception e) {
            System.out.println("Testcase fail: " + e.getMessage());
            e.printStackTrace();
            Assert.assertEquals(true, false, "Total chưa được cập nhật");
        }
    }


    @Test
    // Xác nhận dialog xuất hiện
    public void runTestcase8() {
        try {
            addProductToCart();
            WebElement dialog = test.findElement(By.xpath("/html/body/div[2]/main/div[2]/div[1]/div/div[1]/div/button"));
            dialog.click();
            sleep(3000);
            WebElement dialogText = dialog.findElement(By.xpath("//*[@id=\"deleteLabel\"]")); // Thay đổi XPath để khớp với cấu trúc thực tế của hộp thoại
            String actualText = dialogText.getText();
            sleep(5000);
            String expectedText = "Are you sure?"; // Thay đổi văn bản dự kiến theo yêu cầu kiểm thử
            Assert.assertEquals(actualText, expectedText, "Văn bản trong hộp thoại không khớp");

            System.out.println("Testcase pass");
        } catch (Exception e) {
            System.out.println("Testcase fail: " + e.getMessage());
            e.printStackTrace();
            Assert.assertEquals(true, false);
        }
    }

    @Test
    // Click button X
    public void runTestcase9() {
        try {
            addProductToCart();
            WebElement X = test.findElement(By.xpath("/html/body/div[2]/main/div[2]/div[1]/div/div[1]/form/article/div/div[2]/div[1]/div[2]/a"));
            X.click();
            sleep(7000);
            boolean isOnAddLoginScreen;
            try {
                WebDriverWait wait = new WebDriverWait(test, Duration.ofSeconds(5));
                WebElement Login = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("/html/body/div[2]/main/div[2]/div[1]/div/div[1]/div[1]/div/h2")));
                isOnAddLoginScreen = Login.isDisplayed();
            } catch (NoSuchElementException | TimeoutException e) {
                isOnAddLoginScreen = true;
            }

            try {
                Assert.assertTrue(isOnAddLoginScreen, "Cart is empty");
            } catch (AssertionError e) {
                throw new RuntimeException("Cart is not empty", e);
            }

            System.out.println("Testcase pass");
        } catch (Exception e) {
            System.out.println("Testcase fail: " + e.getMessage());
            e.printStackTrace();
            Assert.assertEquals(true, false);
        }
    }

    @Test
    // Chọn button "No, cancel"
    public void runTestcase10() {
        try {
            addProductToCart();
            WebElement dialog = test.findElement(By.xpath("/html/body/div[2]/main/div[2]/div[1]/div/div[1]/div/button"));
            dialog.click();
            sleep(3000);
            WebElement no = test.findElement(By.xpath("//*[@id=\"delete\"]/div/div/div[3]/a[2]"));
            no.click();
            sleep(5000);
            WebElement Text = dialog.findElement(By.xpath("/html/body/div[2]/main/div[2]/div[1]/div/div[1]/form/article/div/div[2]/div[1]/div[1]/h2/a")); // Thay đổi XPath để khớp với cấu trúc thực tế của hộp thoại
            String actualText = Text.getText();
            sleep(3000);
            String expectedText = "Mens Seamless Trunks"; // Thay đổi văn bản dự kiến theo yêu cầu kiểm thử
            Assert.assertEquals(actualText, expectedText, "Sản phẩm không tồn tại");

            System.out.println("Testcase pass");
        } catch (Exception e) {
            System.out.println("Testcase fail: " + e.getMessage());
            e.printStackTrace();
            Assert.assertEquals(true, false);
        }
    }

    @Test
    // Chọn button "yes, delete it"
    public void runTestcase11() {
        try {
            addProductToCart();
            WebElement dialog = test.findElement(By.xpath("/html/body/div[2]/main/div[2]/div[1]/div/div[1]/div/button"));
            dialog.click();
            sleep(3000);
            WebElement yes = test.findElement(By.xpath("//*[@id=\"delete\"]/div/div/div[3]/a[1]"));
            yes.click();
            sleep(4000);
            boolean isOnAddLoginScreen;
            try {
                WebDriverWait wait = new WebDriverWait(test, Duration.ofSeconds(5));
                WebElement Login = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("/html/body/div[2]/main/div[2]/div[1]/div/div[1]/div[1]/div/h2")));
                isOnAddLoginScreen = Login.isDisplayed();
            } catch (NoSuchElementException | TimeoutException e) {
                isOnAddLoginScreen = true;
            }

            try {
                Assert.assertTrue(isOnAddLoginScreen, "Cart is empty");
            } catch (AssertionError e) {
                throw new RuntimeException("Cart is not empty", e);
            }
        } catch (Exception e) {
            System.out.println("Testcase fail: " + e.getMessage());
            e.printStackTrace();
            Assert.assertEquals(true, false);
        }
    }



    public void updateProductQuantity(String newQuantity) throws InterruptedException {
        WebElement quantityInput = waitCustom.findElementToBeClickableByXPath("/html/body/div[2]/main/div[2]/div[1]/div/div[1]/form/article/div/div[2]/div[2]/div[2]/div/input");
        ((JavascriptExecutor) test).executeScript("arguments[0].value = '';", quantityInput);
        ((JavascriptExecutor) test).executeScript("arguments[0].value = arguments[1]; arguments[0].dispatchEvent(new Event('change'));", quantityInput, newQuantity);
        sleep(5000);
    }

    public void appendToProductQuantity(String additionalValue) throws InterruptedException {
        WebElement quantityInput = waitCustom.findElementToBeClickableByXPath("/html/body/div[2]/main/div[2]/div[1]/div/div[1]/form/article/div/div[2]/div[2]/div[2]/div/input");
        ((JavascriptExecutor) test).executeScript("arguments[0].value += arguments[1]; arguments[0].dispatchEvent(new Event('input'));", quantityInput, additionalValue); // Thêm giá trị mới và kích hoạt sự kiện input
        sleep(5000); // Đợi trang cập nhật
    }
    @AfterMethod
    public void tearDown() {
        if (this.test != null) {
            this.test.quit();
        }

    }

    private void sleep(long millis) {
        try {
            Thread.sleep(millis);
        } catch (InterruptedException var4) {
            InterruptedException e = var4;
            e.printStackTrace();
        }

    }
}
