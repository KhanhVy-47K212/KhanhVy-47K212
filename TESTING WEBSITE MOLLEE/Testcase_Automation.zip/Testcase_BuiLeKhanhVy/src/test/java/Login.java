import WebDriverWaitCustom.WebDriverWaitCustom;
import io.github.bonigarcia.wdm.WebDriverManager;
import org.openqa.selenium.*;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import java.time.Duration;


public class Login {
    WebDriver test;
    WebDriverWaitCustom waitCustom;

    @BeforeMethod
    public void setup() throws InterruptedException {
        WebDriverManager.chromedriver().setup();
        ChromeOptions options = new ChromeOptions();
        options.addArguments("--start-maximized");
        test = new ChromeDriver(options);
        test.get("http://localhost:8080/login?lang=en");

        waitCustom = new WebDriverWaitCustom(test, Duration.ofSeconds(10));
    }
//

    @Test
// Null username
    public void runTestcase1() {
        try {
            // Tìm phần tử 'username' và xóa nội dung
            WebElement user = test.findElement(By.xpath("//input[@name='username']"));
            user.clear();
            // Tìm phần tử 'password' và nhập mật khẩu
            WebElement pass = test.findElement(By.xpath("//input[@name='password']"));
            pass.sendKeys("qMe6Uq");
            // Chờ 3 giây
            sleep(3000);
            // Tìm và click vào nút đăng ký
            WebElement button = test.findElement(By.xpath("//span[@class='button__text']"));
            button.click();
            // Chờ 5 giây
            sleep(5000);
            // Tìm phần tử hiển thị thông báo lỗi cho trường 'username'
            WebElement errorMessage = this.test.findElement(By.id("Username"));
            String actualMessage = errorMessage.getText();
            // Kiểm tra thông báo lỗi
            Assert.assertEquals(actualMessage, "Please fill in this field.");
            System.out.println("Testcase pass");
        } catch (Exception e) {
            // In ra thông báo lỗi nếu có ngoại lệ
            System.out.println("Testcase fail: " + e.getMessage());
            e.printStackTrace();
        }
    }


    @Test
//    Null password
    public void runTestcase2() {
        try {
            WebElement user = test.findElement(By.xpath("//input[@name='username']"));
            user.sendKeys("vyahin6");
            WebElement pass = test.findElement(By.xpath("//input[@name='password']"));
            pass.clear();
            sleep(3000);
            WebElement button = test.findElement(By.xpath("//span[@class='button__text']"));
            button.click();
            sleep(5000);
            WebElement errorMessage = this.test.findElement(By.id("Password"));
            String actualMessage = errorMessage.getText();
            // Kiểm tra thông báo lỗi
            Assert.assertEquals(actualMessage, "Please fill in this field.");
            System.out.println("Testcase pass");
        } catch (Exception e) {
            // In ra thông báo lỗi nếu có ngoại lệ
            System.out.println("Testcase fail: " + e.getMessage());
            e.printStackTrace();
        }
    }

    @Test
//    Null all
    public void runTestcase3() {
        try {
            WebElement user = test.findElement(By.xpath("//input[@name='username']"));
            user.clear();
            WebElement pass = test.findElement(By.xpath("//input[@name='password']"));
            pass.clear();
            sleep(3000);
            WebElement button = test.findElement(By.xpath("//span[@class='button__text']"));
            button.click();
            sleep(5000);
            WebElement errorMessage = this.test.findElement(By.id("Password"));
            String actualMessage = errorMessage.getText();
            // Kiểm tra thông báo lỗi
            Assert.assertEquals(actualMessage, "Please fill in this field.");
            System.out.println("Testcase pass");
        } catch (Exception e) {
            // In ra thông báo lỗi nếu có ngoại lệ
            System.out.println("Testcase fail: " + e.getMessage());
            e.printStackTrace();
        }
    }

    @Test
//    User không tồn tại
    public void runTestcase4() {
        try {
            WebElement user = test.findElement(By.xpath("//input[@name='username']"));
            user.sendKeys("vyahin");
            sleep(3000);
            WebElement pass = test.findElement(By.xpath("//input[@name='password']"));
            pass.sendKeys("qMe6Uq");
            sleep(3000);
            WebElement button = test.findElement(By.xpath("//span[@class='button__text']"));
            button.click();
            sleep(3000);
            WebDriverWait wait = new WebDriverWait(this.test, Duration.ofSeconds(10));
            WebElement errorMessage = wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("username-error")));
            String actualMessage = errorMessage.getText();
            Assert.assertEquals(actualMessage, "Username này không tồn tại!");
            System.out.println("Testcase pass");

        } catch (Exception e) {
            System.out.println("Testcase fail: " + e.getMessage());
            e.printStackTrace();
        }
    }

    @Test
//    Login thành công, không click button Privacy policy
    public void runTestcase5() {
        try {
            WebElement user = test.findElement(By.xpath("//input[@name='username']"));
            user.sendKeys("vyahin6");
            sleep(3000);
            WebElement pass = test.findElement(By.xpath("//input[@name='password']"));
            pass.sendKeys("qMe6Uq");
            sleep(3000);
            WebElement button = test.findElement(By.xpath("//span[@class='button__text']"));
            button.click();
            sleep(5000);
            boolean isOnAddLoginScreen;
            try {
                WebDriverWait wait = new WebDriverWait(test, Duration.ofSeconds(5));
                WebElement Login = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("/html/body/div[2]/main/section[1]/div[1]/h3")));
                isOnAddLoginScreen = Login.isDisplayed();
            } catch (NoSuchElementException | TimeoutException e) {
                isOnAddLoginScreen = true;
            }

            try {
                Assert.assertTrue(isOnAddLoginScreen, "User is not on the Home Screen");
            } catch (AssertionError e) {
                throw new RuntimeException("User is not on the Home Screen", e);
            }

            System.out.println("Testcase pass");
        } catch (Exception e) {
            System.out.println("Testcase fail: " + e.getMessage());
            e.printStackTrace();
        }
    }


    @Test
//    click hyperlink Fogot Password
    public void runTestcase6() {
        try {
            WebElement user = test.findElement(By.xpath("/html/body/div[2]/main/div[2]/div/div[2]/form/div/div[2]/div[2]/span/a"));
            user.click();
            sleep(5000);
            boolean isOnAddLoginScreen;
            try {
                WebDriverWait wait = new WebDriverWait(test, Duration.ofSeconds(5));
                WebElement Login = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("/html/body/div[2]/main/div[2]/div/div[2]/form/div/button/span")));
                isOnAddLoginScreen = Login.isDisplayed();
            } catch (NoSuchElementException | TimeoutException e) {
                isOnAddLoginScreen = true;
            }

            try {
                Assert.assertTrue(isOnAddLoginScreen, "User is not on the Fogot Password Screen");
            } catch (AssertionError e) {
                throw new RuntimeException("User is not on the Fogot Password Screen", e);
            }

            System.out.println("Testcase pass");
        } catch (Exception e) {
            System.out.println("Testcase fail: " + e.getMessage());
            e.printStackTrace();
        }

    }

    @Test
//    click hyperlink Register
    public void runTestcase7() {
        try {
            WebElement user = test.findElement(By.xpath("/html/body/div[2]/main/div[2]/div/div[2]/form/div/div[3]/a"));
            user.click();
            sleep(5000);
            boolean isOnAddLoginScreen;
            try {
                WebDriverWait wait = new WebDriverWait(test, Duration.ofSeconds(5));
                WebElement Login = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("/html/body/div[2]/main/div[2]/div/div[2]/div/form/button/span")));
                isOnAddLoginScreen = Login.isDisplayed();
            } catch (NoSuchElementException | TimeoutException e) {
                isOnAddLoginScreen = true;
            }

            try {
                Assert.assertTrue(isOnAddLoginScreen, "User is not on the Register Screen");
            } catch (AssertionError e) {
                throw new RuntimeException("User is not on the Register Screen", e);
            }

            System.out.println("Testcase pass");
        } catch (Exception e) {
            System.out.println("Testcase fail: " + e.getMessage());
            e.printStackTrace();
        }
    }

    @Test
//    Login thành công, có click button Privacy policy
    public void runTestcase8() {
        try {
            WebElement user = test.findElement(By.xpath("//input[@name='username']"));
            user.sendKeys("vyahin6");
            sleep(3000);
            WebElement pass = test.findElement(By.xpath("//input[@name='password']"));
            pass.sendKeys("qMe6Uq");
            sleep(3000);
            WebElement remember = test.findElement(By.xpath("/html/body/div[2]/main/div[2]/div/div[2]/form/div/div[2]/div[1]/div/label/span[2]"));
            remember.click();
            sleep(3000);
            WebElement button = test.findElement(By.xpath("/html/body/div[2]/main/div[2]/div/div[2]/form/div/button/span"));
            button.click();
            sleep(5000);

            boolean isOnAddLoginScreen;
            try {
                WebDriverWait wait = new WebDriverWait(test, Duration.ofSeconds(5));
                WebElement Login = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("/html/body/div[2]/main/section[1]/div[1]/h3")));
                isOnAddLoginScreen = Login.isDisplayed();
            } catch (NoSuchElementException | TimeoutException e) {
                isOnAddLoginScreen = true;
            }

            try {
                Assert.assertTrue(isOnAddLoginScreen, "User is not on the Home Screen");
            } catch (AssertionError e) {
                throw new RuntimeException("User is not on the Home Screen", e);
            }

            System.out.println("Testcase pass");
        } catch (Exception e) {
            System.out.println("Testcase fail: " + e.getMessage());
            e.printStackTrace();
        }
    }


    @Test
// Kiểm tra chức năng ghi nhớ mật khẩu
    public void runTestcase9() {
        try {
            // Nhập tên người dùng
            WebElement user = test.findElement(By.xpath("//input[@name='username']"));
            user.sendKeys("vyahin6");
            sleep(3000); // Chờ 3 giây để đảm bảo tên người dùng đã được nhập xong
            // Nhập mật khẩu
            WebElement pass = test.findElement(By.xpath("//input[@name='password']"));
            pass.sendKeys("qMe6Uq");
            sleep(3000); // Chờ 3 giây để đảm bảo mật khẩu đã được nhập xong
            // Chọn checkbox "Ghi nhớ mật khẩu"
            WebElement remember = test.findElement(By.xpath("/html/body/div[2]/main/div[2]/div/div[2]/form/div/div[2]/div[1]/div/label/span[1]"));
            remember.click();
            sleep(3000); // Chờ 3 giây để đảm bảo checkbox được chọn
            // Nhấn nút Đăng nhập
            WebElement button = test.findElement(By.xpath("//button[@type='submit']/span"));
            button.click();
            sleep(5000); // Chờ 5 giây để quá trình đăng nhập hoàn tất
            // Click vào tài khoản của tôi
            WebElement me = test.findElement(By.xpath("/html/body/div[2]/header/div/div/div[2]/ul/li[3]/a/span"));
            me.click();
            sleep(3000); // Chờ 3 giây để trang thông tin cá nhân được mở
            // Đăng xuất
            WebElement logout = test.findElement(By.xpath("/html/body/div[2]/header/div/div/div[2]/ul/li[3]/div/ul/li[3]/a"));
            logout.click();
            sleep(5000); // Chờ 5 giây để quá trình đăng xuất hoàn tất
            // Kiểm tra xem thông tin đăng nhập có được lưu lại hay không
            WebElement usernameField = test.findElement(By.id("Username"));
            WebElement passwordField = test.findElement(By.id("Password"));
            try {
                // Kiểm tra xem trường tên người dùng và mật khẩu có được tự động điền không
                Assert.assertEquals(usernameField.getAttribute("value"), "vyahin6", "Tên người dùng không được tự động điền");
                Assert.assertEquals(passwordField.getAttribute("value"), "qMe6Uq", "Mật khẩu không được tự động điền");
                System.out.println("Testcase pass");
            } catch (AssertionError e) {
                System.out.println("Testcase fail: " + e.getMessage());
                Assert.fail("Testcase fail: " + e.getMessage());
            }

        } catch (Exception e) {
            System.out.println("Testcase fail: " + e.getMessage());
            Assert.fail("Testcase fail: " + e.getMessage());
        }
    }


    @AfterMethod
    public void tearDown() {
        if (this.test != null) {
            this.test.quit();
        }

    }

    private void sleep(long millis) {
        try {
            Thread.sleep(millis);
        } catch (InterruptedException var4) {
            InterruptedException e = var4;
            e.printStackTrace();
        }

    }
}