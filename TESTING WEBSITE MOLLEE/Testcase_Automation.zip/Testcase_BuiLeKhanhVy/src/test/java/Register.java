import WebDriverWaitCustom.WebDriverWaitCustom;
import io.github.bonigarcia.wdm.WebDriverManager;
import org.openqa.selenium.*;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;
import java.time.Duration;

public class Register {
    WebDriver test;
    WebDriverWaitCustom waitCustom;

    @BeforeMethod
    public void setup() throws InterruptedException {
        WebDriverManager.chromedriver().setup();
        ChromeOptions options = new ChromeOptions();
        options.addArguments("--start-maximized");
        test = new ChromeDriver(options);
        test.get("http://localhost:8080/register?lang=en");

        waitCustom = new WebDriverWaitCustom(test, Duration.ofSeconds(10));
    }

    @Test
//    Null 1 trường username
    public void runTestcase1() {
        try {
            // Tìm phần tử 'username' và làm trống
            WebElement user = test.findElement(By.xpath("//input[@name='username']"));
            user.clear();
            // Tìm phần tử 'password' và điền mật khẩu vào
            WebElement pass = test.findElement(By.xpath("//input[@name='password']"));
            pass.sendKeys("abc123");
            sleep(3000);
            // Tìm phần tử 'fullname' và điền họ tên vào
            WebElement name = test.findElement(By.xpath("//input[@name='fullname']"));
            name.sendKeys("Khanh Vy");
            sleep(3000);
            // Tìm phần tử 'email' và điền địa chỉ email vào
            WebElement email = test.findElement(By.xpath("//input[@name='email']"));
            email.sendKeys("buvyka@gmail.com");
            sleep(3000);
            // Tìm và click vào checkbox đồng ý điều khoản
            WebElement privacy = test.findElement(By.xpath("//label[@class='checkbox__label']"));
            privacy.click();
            sleep(3000);
            // Tìm và click vào nút đăng ký
            WebElement button = test.findElement(By.xpath("//span[@class='button__text']"));
            button.click();
            sleep(4000);
            // Tìm phần tử hiển thị thông báo lỗi cho trường 'username'
            WebElement errorMessage = test.findElement(By.id("username"));
            String actualMessage = errorMessage.getText();
            // So sánh thông báo lỗi thực tế với thông báo mong muốn
            Assert.assertEquals(actualMessage, "Please fill in this field.");

            System.out.println("Testcase pass");
        } catch (Exception e) {
            System.out.println("Testcase fail: " + e.getMessage());
            e.printStackTrace();
        }
    }

    @Test
    // Username: 1 ký tự
    public void runTestcase2() {
        try {
            // Tìm phần tử 'username' và nhập 1 ký tự
            WebElement user = test.findElement(By.xpath("//input[@name='username']"));
            user.sendKeys("K");
            // Tìm phần tử 'password' và điền mật khẩu vào
            WebElement pass = test.findElement(By.xpath("//input[@name='password']"));
            pass.sendKeys("abc123");
            sleep(3000);
            // Tìm phần tử 'fullname' và điền họ tên vào
            WebElement name = test.findElement(By.xpath("//input[@name='fullname']"));
            name.sendKeys("Khanh Vy");
            sleep(3000);
            // Tìm phần tử 'email' và điền địa chỉ email vào
            WebElement email = test.findElement(By.xpath("//input[@name='email']"));
            email.sendKeys("buvyka@gmail.com");
            sleep(3000);
            // Tìm và click vào checkbox đồng ý điều khoản
            WebElement privacy = test.findElement(By.xpath("//label[@class='checkbox__label']"));
            privacy.click();
            sleep(3000);
            // Tìm và click vào nút đăng ký
            WebElement button = test.findElement(By.xpath("//span[@class='button__text']"));
            button.click();
            sleep(4000);
            // Kiểm tra xem có chuyển đến màn hình login hay không
            boolean isOnAddLoginScreen;
            try {
                WebDriverWait wait = new WebDriverWait(test, Duration.ofSeconds(5));
                WebElement Login = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//h1[@class='inner-top__title']")));
                isOnAddLoginScreen = Login.isDisplayed();
            } catch (NoSuchElementException | TimeoutException e) {
                isOnAddLoginScreen = true;
            }

            // Xác nhận người dùng không chuyển đến màn hình login
            try {
                Assert.assertTrue(isOnAddLoginScreen, "User is not on the Login Screen");
            } catch (AssertionError e) {
                throw new RuntimeException("User is not on the Login Screen", e);
            }

            System.out.println("Testcase pass");
        } catch (Exception e) {
            System.out.println("Testcase fail: " + e.getMessage());
            e.printStackTrace();
        }
    }
    @Test
    // Username: 60 ký tự
    public void runTestcase3() {
        try {
            WebElement user = test.findElement(By.xpath("//input[@name='username']"));
            user.sendKeys(
                    "NhaLanhDaoCongNgheDuaTheGioiDenMotTuongLaiTuoiDepVaPhatTrien");
            WebElement pass = test.findElement(By.xpath("//input[@name='password']"));
            pass.sendKeys("abc123");
            sleep(3000);
            WebElement name = test.findElement(By.xpath("//input[@name='fullname']"));
            name.sendKeys("Khanh Vy");
            sleep(3000);
            WebElement email = test.findElement(By.xpath("//input[@name='email']"));
            email.sendKeys("buvyka@gmail.com");
            sleep(3000);
            WebElement privacy = test.findElement(By.xpath("//label[@class='checkbox__label']"));
            privacy.click();
            sleep(3000);
            WebElement button = test.findElement(By.xpath("//span[@class='button__text']"));
            button.click();
            sleep(4000);
            boolean isOnAddLoginScreen;
            try {
                WebDriverWait wait = new WebDriverWait(test, Duration.ofSeconds(5));
                WebElement Login = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//h1[@class='inner-top__title']")));
                isOnAddLoginScreen = Login.isDisplayed();
            } catch (NoSuchElementException | TimeoutException e) {
                isOnAddLoginScreen = true;
            }

            try {
                Assert.assertTrue(isOnAddLoginScreen, "User is not on the Login Screen");
            } catch (AssertionError e) {
                throw new RuntimeException("User is not on the Login Screen", e);
            }

            System.out.println("Testcase pass");
        } catch (Exception e) {
            System.out.println("Testcase fail: " + e.getMessage());
            e.printStackTrace();
        }
    }
    @Test
    // Username: 61 ký tự
    public void runTestcase4() {
        try {
            WebElement user = test.findElement(By.xpath("//input[@name='username']"));
            user.sendKeys(
                    "NhaLanhDaoCongNgheDuaTheGioiDenMotTuongLaiTuoiDepVaPhatTrien12");
            WebElement pass = test.findElement(By.xpath("//input[@name='password']"));
            pass.sendKeys("qMe6Uq");
            sleep(3000);
            WebElement name = test.findElement(By.xpath("//input[@name='fullname']"));
            name.sendKeys("Khanh Vy");
            sleep(3000);
            WebElement email = test.findElement(By.xpath("//input[@name='email']"));
            email.sendKeys("buvyka@gmail.com");
            sleep(3000);
            WebElement privacy = test.findElement(By.xpath("//label[@class='checkbox__label']"));
            privacy.click();
            sleep(3000);
            WebElement button = test.findElement(By.xpath("//span[@class='button__text']"));
            button.click();
            sleep(4000);
            WebElement errorMessage = test.findElement(By.id("username"));
            String actualMessage = errorMessage.getText();
            Assert.assertEquals(actualMessage, "Username không hợp lệ!");

            System.out.println("Testcase pass");
        } catch (Exception e) {
            System.out.println("Testcase fail: " + e.getMessage());
            e.printStackTrace();
        }
    }

    @Test
//    Null 1 trường password
    public void runTestcase5() {
        try {
            WebElement user = test.findElement(By.xpath("//input[@name='username']"));
            user.sendKeys("KhanhVy");
            WebElement pass = test.findElement(By.xpath("//input[@name='password']"));
            pass.clear();
            sleep(3000);
            WebElement name = test.findElement(By.xpath("//input[@name='fullname']"));
            name.sendKeys("Khanh Vy");
            sleep(3000);
            WebElement email = test.findElement(By.xpath("//input[@name='email']"));
            email.sendKeys("buvyka@gmail.com");
            sleep(3000);
            WebElement privacy = test.findElement(By.xpath("//label[@class='checkbox__label']"));
            privacy.click();
            sleep(3000);
            WebElement button = test.findElement(By.xpath("//span[@class='button__text']"));
            button.click();
            sleep(4000);
            WebElement errorMessage = test.findElement(By.id("Password"));
            String actualMessage = errorMessage.getText();
            Assert.assertEquals(actualMessage, "Please fill in this field.");

            System.out.println("Testcase pass");
        } catch (Exception e) {
            System.out.println("Testcase fail: " + e.getMessage());
            e.printStackTrace();
        }
    }
    @Test
    // Password: ký tự khoảng trống
    public void runTestcase6() {
        try {
            WebElement user = test.findElement(By.xpath("//input[@name='username']"));
            user.sendKeys("KhanhVy");
            WebElement pass = test.findElement(By.xpath("//input[@name='password']"));
            pass.sendKeys(
                    "      ");
            sleep(2000);
            WebElement name = test.findElement(By.xpath("//input[@name='fullname']"));
            name.sendKeys("Khanh Vy");
            sleep(2000);
            WebElement email = test.findElement(By.xpath("//input[@name='email']"));
            email.sendKeys("buvyka@gmail.com");
            sleep(2000);
            WebElement privacy = test.findElement(By.xpath("//label[@class='checkbox__label']"));
            privacy.click();
            sleep(2000);
            WebElement button = test.findElement(By.xpath("//span[@class='button__text']"));
            button.click();
            sleep(4000);
            WebElement testlogin = test.findElement(By.xpath("//html/body/div[2]/main/div[1]/div/div/div[1]/h1"));
            if ("Login".equals(testlogin.getText())){
                System.out.println("Testcase fail");
                Assert.fail("Testcase fail");
            }
            else {
                System.out.println("Testcase pass");}

        } catch (Exception e) {
            System.out.println("Testcase fail: " + e.getMessage());
            e.printStackTrace();
        }
    }

    @Test
    // Password: 5 ký tự
    public void runTestcase7() {
        try {
            WebElement user = test.findElement(By.xpath("//input[@name='username']"));
            user.sendKeys("KhanhVy");
            WebElement pass = test.findElement(By.xpath("//input[@name='password']"));
            pass.sendKeys(
                    "abc12");
            sleep(3000);
            WebElement name = test.findElement(By.xpath("//input[@name='fullname']"));
            name.sendKeys("Khanh Vy");
            sleep(3000);
            WebElement email = test.findElement(By.xpath("//input[@name='email']"));
            email.sendKeys("buvyka@gmail.com");
            sleep(3000);
            WebElement privacy = test.findElement(By.xpath("//label[@class='checkbox__label']"));
            privacy.click();
            sleep(3000);
            WebElement button = test.findElement(By.xpath("//span[@class='button__text']"));
            button.click();
            sleep(4000);

            WebElement testlogin = test.findElement(By.xpath("//html/body/div[2]/main/div[1]/div/div/div[1]/h1"));
            if ("Login".equals(testlogin.getText())){
                System.out.println("Testcase fail");
                Assert.fail("Testcase fail");
            }
            else {
            System.out.println("Testcase pass");}

        } catch (Exception e) {
            System.out.println("Testcase fail: " + e.getMessage());
            e.printStackTrace();
        }
    }

    @Test
    // Passwor: 6 ký tự
    public void runTestcase8() {
        try {
            WebElement user = test.findElement(By.xpath("//input[@name='username']"));
            user.sendKeys("KhanhVy");
            WebElement pass = test.findElement(By.xpath("//input[@name='password']"));
            pass.sendKeys("abc123");
            sleep(3000);
            WebElement name = test.findElement(By.xpath("//input[@name='fullname']"));
            name.sendKeys("Khanh Vy");
            sleep(3000);
            WebElement email = test.findElement(By.xpath("//input[@name='email']"));
            email.sendKeys("buvyka@gmail.com");
            sleep(3000);
            WebElement privacy = test.findElement(By.xpath("//label[@class='checkbox__label']"));
            privacy.click();
            sleep(3000);
            WebElement button = test.findElement(By.xpath("//span[@class='button__text']"));
            button.click();
            sleep(4000);
            boolean isOnAddLoginScreen;
            try {
                WebDriverWait wait = new WebDriverWait(test, Duration.ofSeconds(5));
                WebElement Login = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//h1[@class='inner-top__title']")));
                isOnAddLoginScreen = Login.isDisplayed();
            } catch (NoSuchElementException | TimeoutException e) {
                isOnAddLoginScreen = true;
            }

            try {
                Assert.assertTrue(isOnAddLoginScreen, "User is not on the Login Screen");
            } catch (AssertionError e) {
                throw new RuntimeException("User is not on the Login Screen", e);
            }

            System.out.println("Testcase pass");
        } catch (Exception e) {
            System.out.println("Testcase fail: " + e.getMessage());
            e.printStackTrace();
        }
    }

    @Test
    // Passwor: 60 ký tự
    public void runTestcase9() {
        try {
            WebElement user = test.findElement(By.xpath("//input[@name='username']"));
            user.sendKeys("KhanhVy");
            WebElement pass = test.findElement(By.xpath("//input[@name='password']"));
            pass.sendKeys(
                    "NhaLanhDaoCongNgheDuaTheGioiDenMotTuongLaiTuoiDepVaPhatTrien");
            sleep(3000);
            WebElement name = test.findElement(By.xpath("//input[@name='fullname']"));
            name.sendKeys("Khanh Vy");
            sleep(3000);
            WebElement email = test.findElement(By.xpath("//input[@name='email']"));
            email.sendKeys("buvyka@gmail.com");
            sleep(3000);
            WebElement privacy = test.findElement(By.xpath("//label[@class='checkbox__label']"));
            privacy.click();
            sleep(3000);
            WebElement button = test.findElement(By.xpath("//span[@class='button__text']"));
            button.click();
            sleep(4000);
            boolean isOnAddLoginScreen;
            try {
                WebDriverWait wait = new WebDriverWait(test, Duration.ofSeconds(5));
                WebElement Login = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//h1[@class='inner-top__title']")));
                isOnAddLoginScreen = Login.isDisplayed();
            } catch (NoSuchElementException | TimeoutException e) {
                isOnAddLoginScreen = true;
            }

            try {
                Assert.assertTrue(isOnAddLoginScreen, "User is not on the Login Screen");
            } catch (AssertionError e) {
                throw new RuntimeException("User is not on the Login Screen", e);
            }

            System.out.println("Testcase pass");
        } catch (Exception e) {
            System.out.println("Testcase fail: " + e.getMessage());
            e.printStackTrace();
        }
    }


    @Test
    // Password 61 ký tự
    public void runTestcase10() {
        try {
            WebElement user = test.findElement(By.xpath("//input[@name='username']"));
            user.sendKeys(
                    "NhaLanhDaoCongNgheDuaTheGioiDenMotTuongLaiTuoiDepVaPhatTrien12");
            WebElement pass = test.findElement(By.xpath("//input[@name='password']"));
            pass.sendKeys("qMe6Uq");
            sleep(3000);
            WebElement name = test.findElement(By.xpath("//input[@name='fullname']"));
            name.sendKeys("Khanh Vy");
            sleep(3000);
            WebElement email = test.findElement(By.xpath("//input[@name='email']"));
            email.sendKeys("buvyka@gmail.com");
            sleep(3000);
            WebElement privacy = test.findElement(By.xpath("//label[@class='checkbox__label']"));
            privacy.click();
            sleep(3000);
            WebElement button = test.findElement(By.xpath("//span[@class='button__text']"));
            button.click();
            sleep(4000);
            WebElement errorMessage = test.findElement(By.id("username"));
            String actualMessage = errorMessage.getText();
            Assert.assertEquals(actualMessage, "Username không hợp lệ!");

            System.out.println("Testcase pass");
        } catch (Exception e) {
            System.out.println("Testcase fail: " + e.getMessage());
            e.printStackTrace();
        }
    }
    @Test
//    Null 1 trường name
    public void runTestcase11() {
        try {
            WebElement user = test.findElement(By.xpath("//input[@name='username']"));
            user.sendKeys("KhanhVy");
            WebElement pass = test.findElement(By.xpath("//input[@name='password']"));
            pass.sendKeys("qMe6Uq");
            sleep(3000);
            WebElement name = test.findElement(By.xpath("//input[@name='fullname']"));
            name.clear();
            sleep(3000);
            WebElement email = test.findElement(By.xpath("//input[@name='email']"));
            email.sendKeys("buvyka@gmail.com");
            sleep(3000);
            WebElement privacy = test.findElement(By.xpath("//label[@class='checkbox__label']"));
            privacy.click();
            sleep(3000);
            WebElement button = test.findElement(By.xpath("//span[@class='button__text']"));
            button.click();
            sleep(4000);
            WebElement errorMessage = test.findElement(By.id("Fullname"));
            String actualMessage = errorMessage.getText();
            Assert.assertEquals(actualMessage, "Please fill in this field.");

            System.out.println("Testcase pass");
        } catch (Exception e) {
            System.out.println("Testcase fail: " + e.getMessage());
            e.printStackTrace();
        }
    }
    @Test
//    Null 1 trường email
    public void runTestcase12() {
        try {
            WebElement user = test.findElement(By.xpath("//input[@name='username']"));
            user.sendKeys("KhanhVy");
            WebElement pass = test.findElement(By.xpath("//input[@name='password']"));
            pass.sendKeys("qMe6Uq");
            sleep(3000);
            WebElement name = test.findElement(By.xpath("//input[@name='fullname']"));
            name.sendKeys("Bùi Lê Khánh Vy");
            sleep(3000);
            WebElement email = test.findElement(By.xpath("//input[@name='email']"));
            email.clear();
            sleep(3000);
            WebElement privacy = test.findElement(By.xpath("//label[@class='checkbox__label']"));
            privacy.click();
            sleep(3000);
            WebElement button = test.findElement(By.xpath("//span[@class='button__text']"));
            button.click();
            sleep(4000);
            WebElement errorMessage = test.findElement(By.id("Email"));
            String actualMessage = errorMessage.getText();
            Assert.assertEquals(actualMessage, "Please fill in this field.");

            System.out.println("Testcase pass");
        } catch (Exception e) {
            System.out.println("Testcase fail: " + e.getMessage());
            e.printStackTrace();
        }
    }

    @Test
// Email thiếu ký tự '@'
    public void runTestcase13() {
        try {
            // Tìm phần tử 'username' và nhập tên người dùng
            WebElement user = test.findElement(By.xpath("//input[@name='username']"));
            user.sendKeys("KhanhVy");

            // Tìm phần tử 'password' và nhập mật khẩu
            WebElement pass = test.findElement(By.xpath("//input[@name='password']"));
            pass.sendKeys("abc123");

            // Tìm phần tử 'fullname' và nhập họ tên
            WebElement name = test.findElement(By.xpath("//input[@name='fullname']"));
            name.sendKeys("Khanh Vy");

            // Tìm phần tử 'email' và nhập email thiếu ký tự '@'
            WebElement email = test.findElement(By.xpath("//input[@name='email']"));
            email.sendKeys("buvykagmail.com");

            // Tìm và click vào checkbox đồng ý điều khoản
            WebElement privacy = test.findElement(By.xpath("//label[@class='checkbox__label']"));
            privacy.click();

            // Tìm và click vào nút đăng ký
            WebElement button = test.findElement(By.xpath("//span[@class='button__text']"));
            button.click();

            // Kiểm tra xem không chuyển đến màn hình đăng nhập
            boolean isOnAddLoginScreen;
            try {
                WebDriverWait wait = new WebDriverWait(test, Duration.ofSeconds(5));
                WebElement Login = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("/html/body/div[2]/main/section[1]/div[1]/h3")));
                isOnAddLoginScreen = Login.isDisplayed();
            } catch (NoSuchElementException | TimeoutException e) {
                isOnAddLoginScreen = true;
            }

            try {
                Assert.assertTrue(isOnAddLoginScreen, "User is not on the Login Screen");
            } catch (AssertionError e) {
                throw new RuntimeException("User is not on the Login Screen", e);
            }

            System.out.println("Testcase pass");
        } catch (Exception e) {
            System.out.println("Testcase fail: " + e.getMessage());
            e.printStackTrace();
        }
    }

    @Test
// Email thiếu prefix
    public void runTestcase14() {
        try {
            // Tìm phần tử 'username' và nhập tên người dùng
            WebElement user = test.findElement(By.xpath("//input[@name='username']"));
            user.sendKeys("KhanhVy");

            // Tìm phần tử 'password' và nhập mật khẩu
            WebElement pass = test.findElement(By.xpath("//input[@name='password']"));
            pass.sendKeys("abc123");

            // Tìm phần tử 'fullname' và nhập họ tên
            WebElement name = test.findElement(By.xpath("//input[@name='fullname']"));
            name.sendKeys("Khanh Vy");

            // Tìm phần tử 'email' và nhập email thiếu ký tự '@'
            WebElement email = test.findElement(By.xpath("//input[@name='email']"));
            email.sendKeys("@gmail.com");

            // Tìm và click vào checkbox đồng ý điều khoản
            WebElement privacy = test.findElement(By.xpath("//label[@class='checkbox__label']"));
            privacy.click();

            // Tìm và click vào nút đăng ký
            WebElement button = test.findElement(By.xpath("//span[@class='button__text']"));
            button.click();

            // Kiểm tra xem không chuyển đến màn hình đăng nhập
            boolean isOnAddLoginScreen;
            try {
                WebDriverWait wait = new WebDriverWait(test, Duration.ofSeconds(5));
                WebElement Login = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("/html/body/div[2]/main/section[1]/div[1]/h3")));
                isOnAddLoginScreen = Login.isDisplayed();
            } catch (NoSuchElementException | TimeoutException e) {
                isOnAddLoginScreen = true;
            }

            try {
                Assert.assertTrue(isOnAddLoginScreen, "User is not on the Login Screen");
            } catch (AssertionError e) {
                throw new RuntimeException("User is not on the Login Screen", e);
            }

            System.out.println("Testcase pass");
        } catch (Exception e) {
            System.out.println("Testcase fail: " + e.getMessage());
            e.printStackTrace();
        }
    }
    @Test
// Email thiếu ký tự '@'
    public void runTestcase15() {
        try {
            // Tìm phần tử 'username' và nhập tên người dùng
            WebElement user = test.findElement(By.xpath("//input[@name='username']"));
            user.sendKeys("KhanhVy");

            // Tìm phần tử 'password' và nhập mật khẩu
            WebElement pass = test.findElement(By.xpath("//input[@name='password']"));
            pass.sendKeys("abc123");

            // Tìm phần tử 'fullname' và nhập họ tên
            WebElement name = test.findElement(By.xpath("//input[@name='fullname']"));
            name.sendKeys("Khanh Vy");

            // Tìm phần tử 'email' và nhập email thiếu ký tự '@'
            WebElement email = test.findElement(By.xpath("//input[@name='email']"));
            email.sendKeys("buvyka@");

            // Tìm và click vào checkbox đồng ý điều khoản
            WebElement privacy = test.findElement(By.xpath("//label[@class='checkbox__label']"));
            privacy.click();

            // Tìm và click vào nút đăng ký
            WebElement button = test.findElement(By.xpath("//span[@class='button__text']"));
            button.click();

            // Kiểm tra xem không chuyển đến màn hình đăng nhập
            boolean isOnAddLoginScreen;
            try {
                WebDriverWait wait = new WebDriverWait(test, Duration.ofSeconds(5));
                WebElement Login = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("/html/body/div[2]/main/section[1]/div[1]/h3")));
                isOnAddLoginScreen = Login.isDisplayed();
            } catch (NoSuchElementException | TimeoutException e) {
                isOnAddLoginScreen = true;
            }

            try {
                Assert.assertTrue(isOnAddLoginScreen, "User is not on the Login Screen");
            } catch (AssertionError e) {
                throw new RuntimeException("User is not on the Login Screen", e);
            }

            System.out.println("Testcase pass");
        } catch (Exception e) {
            System.out.println("Testcase fail: " + e.getMessage());
            e.printStackTrace();
        }
    }

    @Test
// Email chứa khoảng trống
    public void runTestcase16() {
        try {
            // Tìm phần tử 'username' và nhập tên người dùng
            WebElement user = test.findElement(By.xpath("//input[@name='username']"));
            user.sendKeys("KhanhVy");

            // Tìm phần tử 'password' và nhập mật khẩu
            WebElement pass = test.findElement(By.xpath("//input[@name='password']"));
            pass.sendKeys("abc123");

            // Tìm phần tử 'fullname' và nhập họ tên
            WebElement name = test.findElement(By.xpath("//input[@name='fullname']"));
            name.sendKeys("Khanh Vy");

            // Tìm phần tử 'email' và nhập email thiếu ký tự '@'
            WebElement email = test.findElement(By.xpath("//input[@name='email']"));
            email.sendKeys("buvy ka @gmail.com");

            // Tìm và click vào checkbox đồng ý điều khoản
            WebElement privacy = test.findElement(By.xpath("//label[@class='checkbox__label']"));
            privacy.click();

            // Tìm và click vào nút đăng ký
            WebElement button = test.findElement(By.xpath("//span[@class='button__text']"));
            button.click();

            // Kiểm tra xem không chuyển đến màn hình đăng nhập
            boolean isOnAddLoginScreen;
            try {
                WebDriverWait wait = new WebDriverWait(test, Duration.ofSeconds(5));
                WebElement Login = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("/html/body/div[2]/main/section[1]/div[1]/h3")));
                isOnAddLoginScreen = Login.isDisplayed();
            } catch (NoSuchElementException | TimeoutException e) {
                isOnAddLoginScreen = true;
            }

            try {
                Assert.assertTrue(isOnAddLoginScreen, "User is not on the Login Screen");
            } catch (AssertionError e) {
                throw new RuntimeException("User is not on the Login Screen", e);
            }

            System.out.println("Testcase pass");
        } catch (Exception e) {
            System.out.println("Testcase fail: " + e.getMessage());
            e.printStackTrace();
        }
    }


    @Test
//    Click hyperlink Login
    public void runTestcase17() {
        try {
            WebElement Loginlink = test.findElement(By.xpath("/html/body/div[2]/main/div[2]/div/div[2]/div/form/div/div[2]/span/a"));
            ((JavascriptExecutor) test).executeScript("arguments[0].scrollIntoView(true);", Loginlink);
            sleep(5000);
            ((JavascriptExecutor) test).executeScript("arguments[0].click();", Loginlink);
            sleep(7000);
            boolean isOnAddLoginScreen;
            try {
                WebDriverWait wait = new WebDriverWait(test, Duration.ofSeconds(5));
                WebElement Login = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("/html/body/div[2]/main/div[2]/div/div[2]/form/div/div[1]/h2")));
                isOnAddLoginScreen = Login.isDisplayed();
            } catch (NoSuchElementException | TimeoutException e) {
                isOnAddLoginScreen = true;
            }

            try {
                Assert.assertTrue(isOnAddLoginScreen, "User is not on the Login Screen");
            } catch (AssertionError e) {
                throw new RuntimeException("User is not on the Login Screen", e);
            }

            System.out.println("Testcase pass");
        } catch (Exception e) {
            System.out.println("Testcase fail: " + e.getMessage());
            e.printStackTrace();
        }
    }
    @Test
//    Đăng ký không thành công ( không click button privacy)
    public void runTestcase18() {
        try {
            WebElement user = test.findElement(By.xpath("//input[@name='username']"));
            user.sendKeys("KhanhVy");
            WebElement pass = test.findElement(By.xpath("//input[@name='password']"));
            pass.sendKeys("abc123");
            sleep(3000);
            WebElement name = test.findElement(By.xpath("//input[@name='fullname']"));
            name.sendKeys("Bùi Lê Khánh Vy");
            sleep(3000);
            WebElement email = test.findElement(By.xpath("//input[@name='email']"));
            email.sendKeys("Buivyka@gmail.com");
            sleep(3000);
            WebElement button = test.findElement(By.xpath("//span[@class='button__text']"));
            button.click();
            sleep(4000);
            String currentUrl = test.getCurrentUrl();
            String loginPageUrl = "http://localhost:8080/login"; // Thay đổi URL theo trang Login của bạn

            if (currentUrl.equals(loginPageUrl)) {
                // Nếu URL hiện tại là màn hình Login, đánh dấu kiểm thử thất bại
                Assert.fail("Màn hình đã chuyển hướng đến trang đăng nhập khi không chọn hộp kiểm privacy.");
            }


            System.out.println("Testcase pass");
        } catch (Exception e) {
            System.out.println("Testcase fail: " + e.getMessage());
            e.printStackTrace();
        }
    }

    @Test
//    Đăng ký thành công ( click button privacy)
    public void runTestcase19() {
        try {
            WebElement user = test.findElement(By.xpath("//input[@name='username']"));
            user.sendKeys("KhanhVy");
            WebElement pass = test.findElement(By.xpath("//input[@name='password']"));
            pass.sendKeys("qMe6Uq");
            sleep(3000);
            WebElement name = test.findElement(By.xpath("//input[@name='fullname']"));
            name.sendKeys("Bùi Lê Khánh Vy");
            sleep(3000);
            WebElement email = test.findElement(By.xpath("//input[@name='email']"));
            email.sendKeys("Buivyka@gmail.com");
            sleep(3000);
            WebElement privacy = test.findElement(By.xpath("//label[@class='checkbox__label']"));
            privacy.click();
            sleep(3000);
            WebElement button = test.findElement(By.xpath("//span[@class='button__text']"));
            button.click();
            sleep(4000);
            boolean isOnAddLoginScreen;
            try {
                WebDriverWait wait = new WebDriverWait(test, Duration.ofSeconds(5));
                WebElement Login = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("/html/body/div[2]/main/div[2]/div/div[2]/form/div/div[1]/h2")));
                isOnAddLoginScreen = Login.isDisplayed();
            } catch (NoSuchElementException | TimeoutException e) {
                isOnAddLoginScreen = true;
            }

            try {
                Assert.assertTrue(isOnAddLoginScreen, "User is not on the Login Screen");
            } catch (AssertionError e) {
                throw new RuntimeException("User is not on the Login Screen", e);
            }

            System.out.println("Testcase pass");
        } catch (Exception e) {
            System.out.println("Testcase fail: " + e.getMessage());
            e.printStackTrace();
        }
    }

    @Test
//    Test đăng nhập thành công tài khoản vừa tạo
    public void runTestcase20() {
        try {
            WebElement user = test.findElement(By.xpath("//input[@name='username']"));
            user.sendKeys("KhanhVy");
            WebElement pass = test.findElement(By.xpath("//input[@name='password']"));
            pass.sendKeys("qMe6Uq");
            sleep(3000);
            WebElement name = test.findElement(By.xpath("//input[@name='fullname']"));
            name.sendKeys("Bùi Lê Khánh Vy");
            sleep(3000);
            WebElement email = test.findElement(By.xpath("//input[@name='email']"));
            email.sendKeys("Buivyka@gmail.com");
            sleep(3000);
            WebElement privacy = test.findElement(By.xpath("//label[@class='checkbox__label']"));
            privacy.click();
            sleep(3000);
            WebElement button = test.findElement(By.xpath("//span[@class='button__text']"));
            button.click();
            sleep(4000);
            WebElement username = test.findElement(By.xpath("//input[@name='username']"));
            username.sendKeys("KhanhVy");
            sleep(3000);
            WebElement password = test.findElement(By.xpath("//input[@name='password']"));
            password.sendKeys("qMe6Uq");
            sleep(3000);
            WebElement Loginbutton = test.findElement(By.xpath("/html/body/div[2]/main/div[2]/div/div[2]/form/div/button/span"));
            Loginbutton.click();
            sleep(5000);
            boolean isOnAddLoginScreen;
            try {
                WebDriverWait wait = new WebDriverWait(test, Duration.ofSeconds(5));
                WebElement Login = wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("/html/body/div[2]/main/section[1]/div[1]/h3")));
                isOnAddLoginScreen = Login.isDisplayed();
            } catch (NoSuchElementException | TimeoutException e) {
                isOnAddLoginScreen = true;
            }

            try {
                Assert.assertTrue(isOnAddLoginScreen, "User is not on the Home Screen");
            } catch (AssertionError e) {
                throw new RuntimeException("User is not on the Home Screen", e);
            }

            System.out.println("Testcase pass");
        } catch (Exception e) {
            System.out.println("Testcase fail: " + e.getMessage());
            e.printStackTrace();
        }
    }


    @AfterMethod
        public void cleanup(){
            test.quit();
        }
        private void sleep(int time){
            try{
                Thread.sleep(time);
            }catch (Exception ex){
                System.out.println(ex.getMessage());
            }
        }
}
