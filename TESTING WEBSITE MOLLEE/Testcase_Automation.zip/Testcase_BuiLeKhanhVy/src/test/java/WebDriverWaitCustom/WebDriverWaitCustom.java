package WebDriverWaitCustom;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.time.Duration;

public class WebDriverWaitCustom {
    private final WebDriverWait driverWait;

    public WebDriverWaitCustom(WebDriver driver, Duration duration) {
        this.driverWait = new WebDriverWait(driver, duration);
    }

    public WebElement findElementToBeClickableByXPath(String xpathExpression) {
        return driverWait.until(ExpectedConditions.elementToBeClickable(By.xpath(xpathExpression)));
    }

    public WebElement until(ExpectedCondition<WebElement> dialog) {
        return null;
    }

}